#-------------------------------------------------#
# Title: Working with Functions & Classes
# Dev:   RRoot
# Date:  Sept 16, 2017
# ChangeLog: (Who, When, What)
#   RRoot, 09/16/2017, Created Script
#   JHundrup, 8/19/2018, put code from Assignment #5 into class & functions

#-------------------------------------------------#

#-- Data Code --#
#declare variables and constants
objFileName = "C:\_PythonClass\Jeremy_Hundrup_Assignment06\Todo.txt" #represents my Todo.txt file
strData = "" #row of text data from the file
dicRow = {} #row of data put into elements of a dictionary
lstTable = [] #dictionary that will act like a table of rows
userChoice = ""

#-- Processing --#
class TodoFunctions(object):
    '''This class contains all the functions used to work with the Todo list.'''

    @staticmethod #defines the method
    def loadData():
        '''Step 1: When the program starts, load the data you have
        in a text file called ToDo.txt into a python Dictionary.'''
        objFile = open(objFileName, "r")
        for line in objFile:
            strData = line.split(",") # readline() reads a line of the data into 2 elements
            dicRow = {"Task":strData[0].strip(), "Priority":strData[1].strip()}
            lstTable.append(dicRow)
        objFile.close()
        #print(lstTable)
        return lstTable

    @staticmethod  # defines the method
    def displayMenu():
        '''Step 2: Display a menu of choices to the user'''
        print ("""
        Menu of Options
        1) Show current data
        2) Add a new item.
        3) Remove an existing item.
        4) Save Data to File
        5) Exit Program
        """)
        strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
        return strChoice
        print()#adding a new line

    @staticmethod  # defines the method
    def displayTodo():
        '''Step 3: Display all todo items to user'''
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")

    @staticmethod  # defines the method
    def addTask():
        '''Step 4: Add a new item to the list/Table'''
        strTask = str(input("What is the task? - ")).strip()
        strPriority = str(input("What is the priority? [high|low] - ")).strip()
        print() #adds a row
        dicRow = {"Task": strTask, "Priority": strPriority}
        lstTable.append(dicRow)
        print("Current Data in table:")
        for dicRow in lstTable:
            print(dicRow)
        print()  # adds a row
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")

    @staticmethod  # defines the method
    def removeTask():
        '''Step 5: Remove a new item to the list/Table'''
        ##elif(strChoice == '3'):
        #5a-Allow user to indicate which row to delete
        strKeyToRemove = input("Which TASK would you like removed? - ")
        blnItemRemoved = False #Creating a boolean Flag
        intRowNumber = 0
        while(intRowNumber < len(lstTable)):
            if(strKeyToRemove == str(list(dict(lstTable[intRowNumber]).values())[0])): #the values function creates a list!
                del lstTable[intRowNumber]
                blnItemRemoved = True
            #end if
            intRowNumber += 1
        #end for loop
        #5b-Update user on the status
        if(blnItemRemoved == True):
            print("The task was removed.")
        else:
            print("I'm sorry, but I could not find that task.")

        #5c Show the current items in the table
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")

    @staticmethod  # defines the method
    def saveTasks():
        '''Step 6: Save tasks to the ToDo.txt file'''
        #elif(strChoice == '4'):
        #5a Show the current items in the table
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")
        #5b Ask if they want save that data
        if("y" == str(input("Save this data to file? (y/n) - ")).strip().lower()):
            objFile = open(objFileName, "w")
            for dicRow in lstTable:
                objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
            objFile.close()
            input("Data saved to file! Press the [Enter] key to return to menu.")
        else:
            input("New data was NOT Saved, but previous data still exists! Press the [Enter] key to return to menu.")
        ##continue #to show the menu
    @staticmethod  # defines the method
    def finish():
        '''Step 7: Exit program'''
        exit()

#-- Input/Output --#
# User can see a Menu (Step 2)
TodoFunctions.loadData()
while(True):
    userChoice = TodoFunctions.displayMenu()
    # User can see data (Step 3)
    if(userChoice.strip() == '1'):
        TodoFunctions.displayTodo()

    # User can insert or delete data(Step 4 and 5)
    elif(userChoice.strip() == '2'):
        TodoFunctions.addTask()
    elif(userChoice.strip() == '3'):
        TodoFunctions.removeTask()
    # User can save to file (Step 6)
    elif(userChoice.strip() == '4'):
        TodoFunctions.saveTasks()
    elif(userChoice.strip() == '5'):
            TodoFunctions.finish()